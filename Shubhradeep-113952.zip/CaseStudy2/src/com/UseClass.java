package com;

 

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

 

public class UseClass {

 

       public static void main(String[] args) {

              Student s1=new Student("QQQQ", 'M', LocalDate.of(1991, 8, 12));
              Student s2=new Student("AAAA", 'M', LocalDate.of(2000, 07, 11));
              Student s3=new Student("PPPP", 'M', LocalDate.of(1994, 06, 10));
              Student s4=new Student("YYYY", 'M', LocalDate.of(1995, 05, 9));
              Student s5=new Student("XXXX", 'M', LocalDate.of(1992, 04, 8));


              ArrayList<Student> stud=new ArrayList<>();

              
             

              //System.out.println("size is "+stud.size());

              stud.add(s1);
              stud.add(s2);
              stud.add(s3);
              stud.add(s4);
              stud.add(s5);
              
              ArrayList<Student> sty=new ArrayList<>();

              for(int i=0;i<stud.size();i++) {
                   stud.get(i).registerStudent(sty);
               
              }
              
              
              Registrar regis=new Registrar();
              regis.displaystudent(sty);
              Collections.sort(sty, new Registrar());
              System.out.println();
              System.out.println("Sorted by STUDENT NAME");
              regis.displaystudent(sty);
              
              for(int j=0;j<sty.size();j++) {
              stud.get(j).registerForExam(sty.get(j));
              }
              
              
              
              Student s6=new Student();
              Scanner sc=new Scanner(System.in);
              while(true) {
               System.out.println();
               System.out.println("Enter new Student name who wants to enroll ");
               s6.setsName(sc.next());
               System.out.println("Enter Sex");
               s6.setSex(sc.next().charAt(0));
               System.out.println("Enter DOB in YYYY<ENTER>, then MM<ENTER> and DD<ENTER> ");
               //s6.setDob(LocalDate.of(year, month, dayOfMonth));
               s6.setDob(LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt()));
               
               
               stud.add(s6);
               //sc.close();
               
                  sty=stud.get(stud.size()-1).registerStudent(sty);
                 
                
                  
                  Collections.sort(sty, new Registrar());
                  System.out.println();
                  System.out.println("Sorted by STUDENT NAME");
                  regis.displaystudent(sty);
               
              
               
               
              }
              

            

       }

 

}

 

