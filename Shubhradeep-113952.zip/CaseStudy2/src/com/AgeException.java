package com;

public class AgeException extends Exception {

	// Checked -> extends Exception
	// UnChecked -> extends RuntimeException

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AgeException(String msg) {

		super(msg);
	}
}
