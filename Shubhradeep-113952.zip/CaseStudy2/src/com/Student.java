package com;

 

import java.time.LocalDate;

import java.time.Period;
import java.util.ArrayList;

 

public class Student {

 

                String sName;
                int age;
                char sex;
                LocalDate dob;
                String admissionId;
                String result;

public Student() {

}
                
public Student(String sName, char sex, LocalDate dob) {

                                this.sName = sName;
                                //Period period=Period.between(getDob(), LocalDate.now());
                                //this.age=period.getYears();
                                this.sex = sex;
                                this.dob = dob;
                                //this.admissionId=admissionId;
                                //this.result = result;

                }




public String getsName() {

                return sName;

}

 

public void setsName(String sName) {

                this.sName = sName;

}



public int getAge() {

                Period period=Period.between(getDob(), LocalDate.now());
                this.age=period.getYears();
                return age;

}


public char getSex() {

                return sex;

}

 

public void setSex(char sex) {

                this.sex = sex;

}

 

public LocalDate getDob() {

                return dob;

}

public void setDob(LocalDate dob) {

                this.dob = dob;

}



public String getResult() {

                return result;

}

 

public void setResult(String result) {

                this.result = result;

}

 

public String getadmissionId() {

                return admissionId;

}

 

public void setadmissionId(String admissionId) {

                this.admissionId = admissionId;

}

 

/*if (student.admissionId != "0000") {

student.registerForExam();

student.appearForExam();

} */

 


ArrayList<Student> registerStudent(ArrayList<Student> stp) {

				Registrar registrar=Registrar.getRegistrar();
                stp=registrar.registerStudent(this,stp);
                return stp;
                }


void registerForExam(Student student) {

                ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
                examRegistrar.registeringStudentForExamination(student);

 
}

}

