package com;

 

public class Validator {

      

       static Validator getValidator(){

              return new Validator();

             

       }

      

       Boolean validateStudentDetails (Student student){

                     if (student.getAge()>22&&student.getAge()<36){

                           System.out.println("Student "+student.getsName()+" Validated");

                           return true;

                     }

                     else {

                           try {

                                  throw new AgeException("Age "+student.getAge()+" beyond permissible limit");

                           } catch (AgeException e) {

                                  System.out.println(e);

                                  return false;     

                                 

                           }

                    

              }

  

       }

 

}



