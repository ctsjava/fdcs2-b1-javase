package com;

 

import java.util.ArrayList;
import java.util.Comparator;

import com.Registrar;

import com.Student;

import com.Validator;

 

public class Registrar implements Comparator<Student>{

int maxSeats=5;


       static Registrar getRegistrar() {
        
           return new Registrar();

       }


       ArrayList<Student> registerStudent(Student student, ArrayList<Student> sl){
          
       
      

              Validator validator=Validator.getValidator();
              
              if(sl.size()<maxSeats) {
              if(validator.validateStudentDetails(student)) {
                  sl.add(student);  
               }else {
                      System.out.println("Student not enrolled");
               }
              }else {
                System.out.println("Max seat reached...cannot enroll");
            }
               
              //System.out.println(sl.get(0).getsName());
              // System.out.println("Size is "+sl.size());
                

             return sl;

       }
       
       void displaystudent(ArrayList<Student> studentenroll) {
    	System.out.println("--------------------------------------------");   
        System.out.println("Name"+"\t"+"Sex"+"\t"+"Date of Birth"+"\t"+"Age");
        System.out.println("--------------------------------------------");
        for(Student stx:studentenroll) {
         System.out.print(stx.getsName()+"\t");
         System.out.print(stx.getSex()+"\t");
         System.out.print(stx.getDob()+"\t");
         System.out.print(stx.getAge());
         System.out.println();
        }
       }


@Override
public int compare(Student s1, Student s2) {
 // TODO Auto-generated method stub
 return s1.getsName().compareTo(s2.getsName());
}

}

