package com;

import com.Evaluator;
import com.Paper;

public class Evaluator {
	
	
	public static Evaluator getEvaluator() {
		return new Evaluator();
	}
	
	String evaluate(Paper paper) {
		return "pass";
	}

}
