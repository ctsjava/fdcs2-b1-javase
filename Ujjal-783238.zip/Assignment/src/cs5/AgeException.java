package cs5;

public class AgeException extends Exception {
	
	String msg;
	AgeException(String msg)
	{
		this.msg=msg;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ("Exception !!! "+msg);
	}

}
