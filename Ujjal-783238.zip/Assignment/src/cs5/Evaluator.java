package cs5;

public class Evaluator {
	
	public static Evaluator getEvaluator()
	{
		 return new Evaluator();
	} 
	public String evaluate(Paper pr)
	{
		System.out.println("Evaluating paper");
		return "Pass";
	}
}
