package caseStudy5;


import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

class SortByStdAge implements Comparator<Student>{
	
	@Override
	public int compare(Student o1, Student o2) {
		
		return o1.getStudentAge() - o2.getStudentAge();
	}
}

public class Registrar implements MaxCollegeSeat{	
	
	private int avlblSeats;	

	Vector<Student> registerStudent(Student[] std) {
		
		Vector<Student> ar=new Vector<>();
		
		avlblSeats = maxseat - std.length;
		
		System.out.println("Registrar gets available seats : " + avlblSeats);
		System.out.println();
		
		if (avlblSeats >= 0 ) {
			
			Validator vd=new Validator();
			vd.availableSeats(avlblSeats);
			
			for (Student stdobj:std) {
				
				if (vd.validateStudent(stdobj) == "Successfully validated") {
					
					ar.add(stdobj);	
				} else {
					System.out.println(vd.validateStudent(stdobj));
					System.out.println();
				}
				
			}
			
		} else {
			System.out.println("Reached max seat limit, registration stopped"); 
		}
		
		Collections.sort(ar, new SortByStdAge());
		return ar;
		
	}
	
	void display(Vector<Student> stdobj) {
				
		if (stdobj.size() > 0) {
		System.out.println("Student Name" + "\t" + "Student Age");
		System.out.println("---------------------------------------------");		
			for (Student st:stdobj) {
				System.out.println(st.getStudentName() + "\t" + st.getStudentAge());
				
			}
		}
		
	}

}
