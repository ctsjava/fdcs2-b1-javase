package caseStudy5;

import java.util.Vector;

public class Use {

	public static void main(String[] args) {
		
		Student[] st=new Student[3];
		
		st[0]=new Student("Student1",26);
		st[1]=new Student("Student2",25);
		st[2]=new Student("Student3",27);
		
		Vector<Student> al=null;
		//call register
		Registrar rg=new Registrar();
		al=rg.registerStudent(st);
		
		//display all registered students
		rg.display(al);
		System.out.println();
		
		//call examiner
		Examiner examiner=new Examiner();
		Exam exam=examiner.conductExam(al);
		Paper paper=null;
		
		for (Student std:al) {
			
			paper=exam.getPaper();
			if (paper.submit()=="Pass" ) {
				System.out.println(std.getStudentName() + " got succesfully admitted");
			}
			
		}
		
	}

}

