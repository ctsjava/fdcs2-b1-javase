package caseStudy5;

public class Evaluator {
	
	String evaluate(Paper paper) {
		
		return "Pass";
		
	}

}