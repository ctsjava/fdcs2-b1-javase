package caseStudy5;

public class Paper {
	
	String submit() {
		
		Evaluator eval=new Evaluator();
		return eval.evaluate(this);
	}

}