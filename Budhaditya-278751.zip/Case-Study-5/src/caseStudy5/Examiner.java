package caseStudy5;

import java.util.Vector;

public class Examiner {	
	
	Exam conductExam(Vector<Student> alstd ) {
			   
		Paper paper=new Paper();
		Exam exam=new Exam(paper);
	
		return exam;
	}

}
