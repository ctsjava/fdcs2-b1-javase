package caseStudy5;

public class Exam {
	
private Paper paper;

	public Exam(Paper paper) {
		this.paper = paper;
	}

	public Paper getPaper(){
	 return paper;
	}
	
	
	

}
