package com;

public class Evaluator {
	
	Evaluator(){}
	
	public static Examiner getEvaluator(){
		return Examiner.getExamRegistrar();
	}
	
	public String evaluate(Paper p) {
		String result = "Pass";
		return  result;
	}
}
