package com;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;


public class MainApp {

	static Student s1 = new Student("Arin", "Single", 'M', LocalDate.of(1989, 06, 06), "Kolkata", "arin@gmail.com", "None", "100", "B-Tech", "Indian");
	static Student s2 = new Student("Kaustav", "Married", 'M', LocalDate.of(1950, 02, 03), "Durgapur", "kaus@yahoo.com", "None", "200", "B-Tech", "Indian");
	static Student s3 = new Student("Subhra", "Single", 'M', LocalDate.of(1990, 04, 05), "Medinapore", "sub@gmail.com", "None", "300", "M-Tech", "Indian");
	static Student s4 = new Student("Supriyo", "Married", 'M', LocalDate.of(1985, 06, 07), "Shibpur", "sup@gmail.com", "None", "400", "B-Tech", "Indian");
	static Student s5 = new Student("Nandini", "Married", 'F', LocalDate.of(1992, 07, 07), "Salt Lake", "nan@gmail.com", "None", "500", "B-Tech", "Indian");

	public static void main(String[] args) {		

		ArrayList<Student> stdArray = new ArrayList<Student>();
		stdArray.add(s1);
		stdArray.add(s2);
		stdArray.add(s3);
		stdArray.add(s4);
		stdArray.add(s5);

		System.out.println("Original Data");
		System.out.println("*******************************************************************************************************************************************************************************************");
		Student.display(stdArray);

		System.out.println();
		System.out.println("Sort by Student Age ASC to DSC");
		System.out.println("*******************************************************************************************************************************************************************************************");
		Collections.sort(stdArray);
		Student.display(stdArray);


		Registrar reg = Registrar.getRegistrar();
		for(int i = 0 ; i<stdArray.size(); i++) {
			Student std=stdArray.get(i);
			int j=i+1;
			std.setSeatCount(j);
			std.admitStudent();
//			reg.studentDetails(std);
			if(std.getAdmissionId()!=0) {
				std.registerForExam();
				std.appearForExam();
			}
		}

	}
}
