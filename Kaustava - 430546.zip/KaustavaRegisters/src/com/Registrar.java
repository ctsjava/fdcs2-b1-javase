package com;

import java.util.Random;
import java.util.TreeSet;

public class Registrar {

	private int i = 0;
	

	private Registrar() {
	}

	public static Registrar getRegistrar() {
		Registrar reg = new Registrar();
		return reg;
	}

	int registerStudent(Student std) {
		int admitId = 0;
		Validator val = Validator.getValidator();
		i++;

		try {
			System.out.println("Getting seat count: "+std.getSeatCount());
			System.out.println("Getting Max seat: "+std.max_seat);
			if (std.getSeatCount() > std.max_seat) {
				System.out.println("Sorry all the seat are registered!!");
				admitId = -1;
				return admitId;
			}
			if (val.validateStudentDetails(std) == "thanks" && (std.getSeatCount() < std.max_seat)) {
				System.out.println("*********************Congratulations***************************");
				System.out.println("******************Student Registered***************************");
				i++;
				std.setSeatCount(i);
				Random r = new Random();
				admitId = r.nextInt(40000);
			}
		} catch (AgeExceptionclass e) {
			System.out.println("Age is : not between 23 and 30 , it is : "+std.getAge());
			e.printStackTrace();
		}
		return admitId;

	}

	
	 void studentDetails(Student std) { 
		TreeSet ts = new TreeSet();
	  	ts.add(std); 
	  	
	  }
	 

}
