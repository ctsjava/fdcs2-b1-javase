package com;

public class Examiner {
	
	private Examiner() {}

	static Examiner getExamRegistrar() {
		Examiner exr = new Examiner();
		return exr;
	}
	
	public Exam registeringStudentForExamination(Student std){
		Paper p = new Paper();
		Exam ex = new Exam(p);
		return ex;
		
	}
	
}
