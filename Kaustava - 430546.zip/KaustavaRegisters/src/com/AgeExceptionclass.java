package com;

public class AgeExceptionclass extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 20L;
	public AgeExceptionclass(String message)
	  {
	    super(message);
	  }
}
