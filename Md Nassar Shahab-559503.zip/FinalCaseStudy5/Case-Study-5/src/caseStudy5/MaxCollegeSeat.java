package caseStudy5;

public interface MaxCollegeSeat {
	
	int maxseat=30;	

}