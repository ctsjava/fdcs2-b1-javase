package caseStudy5;


public class Validator {
	
	private int avlseat;
	
	void availableSeats(int avlseat) {
		
		this.avlseat=avlseat;	
		System.out.println("Validator gets available seats : " + this.avlseat);
		System.out.println();
		
	}
	
	String validateStudent(Student stdobj) {			
		
		  try {
			  
			  if (stdobj.getStudentAge() > 35 || stdobj.getStudentAge() < 23 ) {
				  
				  throw new AgeException(stdobj.getStudentName() + " : Not a valid age");
				  
			  } else {
				  
				  return "Successfully validated" ;
			  }
			
		} catch (AgeException e) {
			
		   return e.getMessage();
			
		}
		
	}

}
