package com;

public class AgeException extends Exception {
	
	String msg;
	AgeException(String msg)
	{
		this.msg=msg;
	}
	@Override
	public String toString() {
		return ("AgeException:: "+msg);
	}

}

