package com;


public class SizeException extends Exception{
	
	String msg;
	SizeException(String msg)
	{
		this.msg=msg;
	}
	@Override
	public String toString() {
		return ("Exception !!!"+msg);
	}
}

