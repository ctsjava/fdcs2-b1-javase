package com;

public class Examiner {

	private String result;
	
	public void createExam()
	{
		Paper pr=new Paper();
		System.out.println("Extracting paper for exam");
		Exam ex=new Exam(pr);
		System.out.println("Passing paper to Evaluator");
		evaluatePaper(ex.getPaper());
	}
	
	public  void evaluatePaper(Paper pp)
	{
		this.result=Evaluator.getEvaluator().evaluate(pp);
	}
	
	public String getResult()
	{
		return result;
	}
}
