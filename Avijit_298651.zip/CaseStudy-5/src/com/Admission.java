package com;

import java.util.ArrayList;
import java.util.Collections;

public class Admission {
	public static void main(String[] args) {
		
		Student s1 = new Student("Avijit", "Married", 25, 'M', "10/7/1994", "Kolkata", "123@abc.com", "456@xyz.com",
				9876543765L, "Java", "Mtech", "Indian");
		Student s2 = new Student("James", "Single", 26, 'F', "10/7/1993", "Bangalore", "321@abc.com", "789@xyz.com",
				9876543766L, "Java", "Btech", "Indian");
		Student s3 = new Student("Raja", "Single", 31, 'F', "10/7/1987", "Delhi", "abc@abc.com", "xyz@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		Student s4 = new Student("Sumon", "Single", 27, 'M', "10/7/1992", "Kolkata", "987@abc.com", "47xyz@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		Student s5 = new Student("Lisa", "Single", 35, 'F', "10/7/1991", "Orissa", "a23bc@abc.com", "xyz12@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		Student s6 = new Student("Moumita", "Single", 25, 'M', "10/7/1994", "Kolkata", "134@abc.com", "xyz@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		Student s7 = new Student("Kausik", "Single", 27, 'M', "10/7/1992", "Orissa", "678@abc.com", "xyz@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		
		Registrar rs=new Registrar();
		ArrayList al=new ArrayList();
		
		rs.registerStudent(al, s1);
		rs.registerStudent(al, s2);
		rs.registerStudent(al, s3);
		rs.registerStudent(al, s4);
		rs.registerStudent(al, s5);
		rs.registerStudent(al, s6);
		rs.registerStudent(al, s7);
		rs.evaluationProcess(al);
		
		System.out.println("------ Displaying Students ------");
		System.out.println();
		rs.displayStudent(al);
		System.out.println();
		
		System.out.println("------ Sorting Based On Name ------");
		System.out.println();
		Collections.sort(al, rs.sortName());
		rs.displayStudent(al);
	}
}
