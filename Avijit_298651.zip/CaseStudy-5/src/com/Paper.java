package com;

public class Paper {

}
