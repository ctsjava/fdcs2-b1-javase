package com;

public class Exam {

Paper paper;

Exam(Paper paper) {  
 //System.out.println("Inside Exam -> Exam");
 this.paper=paper;
}

Paper getPaper() {
 //System.out.println("Inside Exam -> getPaper");
 return paper;
}

}