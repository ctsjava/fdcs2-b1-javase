package com;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;
import java.util.Comparator;

public class Student implements Serializable, Comparable<Student>, Comparator<Student>{

private String Name;
private LocalDate DateofBirth;
private int age;
private final int maxLim = 30;

public Student() {
 
}

public String getName() {
 return Name;
}

public int getMaxLim() {
 return maxLim;
}

public void setName(String name) {
 Name = name;
}

public LocalDate getDateofBirth() {
 return DateofBirth;
}

public void setDateofBirth(LocalDate dateofBirth) {
 DateofBirth = dateofBirth;
}

public int getAge() {
 Period period = Period.between(getDateofBirth(), LocalDate.now());
 this.age = period.getYears();
 return this.age;
}

    public Student(String name, LocalDate dateofBirth) {
 super();
 Name = name;
 DateofBirth = dateofBirth;
}

@Override
public int compareTo(Student arg0) {
 // TODO Auto-generated method stub
 return (this.age - arg0.getAge());
}

@Override
public int compare(Student o1, Student o2) {
 // TODO Auto-generated method stub
 return o1.getName().compareTo(o2.getName());
}


}
