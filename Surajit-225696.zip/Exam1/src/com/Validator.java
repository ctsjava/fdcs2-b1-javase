package com;

public class Validator {

Validator() {
 
}

static Validator getValidator() {
 //System.out.println("inside Validator -> getValidator");
 return new Validator();
}

boolean validateStudentDetails (Student student) 
  throws AgeException  {
 //System.out.println("inside Validator -> validateStudentDetails");
 if ((student.getAge() >= 23) && (student.getAge() <= 35)) {
  return true;
 } else {
  throw new AgeException(student.getAge() + " Age for " + student.getName() + " is out of bounds");
 }  
  }

}