package com;

public class Paper {

boolean submit() {
 //System.out.println("inside Paper -> submit");
 Evaluator evaluator=Evaluator.getEvaluator();
 if (evaluator.evaluate(this)== "Pass") {
  return true;
 }else{
  return false;
 }
}

}