package com;

public class Evaluator {

Evaluator () {
 
}

static Evaluator getEvaluator() {
 //System.out.println("inside Evaluator -> getEvaluator ");
 return new Evaluator();
}

String evaluate(Paper paper) {
 //System.out.println("inside Evaluator ->  evaluate");
 return "Pass";
}

}