package com;

public class ExamRegistrar {

ExamRegistrar() {
 
}

static ExamRegistrar getExamRegistrar () {
 //System.out.println("inside ExamRegistrar -> getExamRegistrar ");
 return new ExamRegistrar();
}

Exam registeringStudentForExamination (Student student) {
 //System.out.println("inside ExamRegistrar -> registeringStudentForExamination ");
 Paper paper=new Paper();
 Exam exam=new Exam(paper);
 return exam;
}
}