package com;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Use {

	static int admissionId;
	static Exam exam;
	static boolean result1;

	public static void main(String[] args) {
 
		Scanner sc = new Scanner(System.in);
		DateTimeFormatter datetimeformater = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String studentName = null;
		String studentDOB = null;
		String option = null;
		boolean yes = true;
 
 //ArrayList<Student> stu = new ArrayList<>();
 //stu.add(new Student ("Surajit", LocalDate.of(1990, 05, 17)));
 //stu.add(new Student ("Ranita", LocalDate.of(1996, 05, 17)));
 //stu.add(new Student ("Abhijit", LocalDate.of(1995, 05, 17)));
 
 //Student student=new Student("Surajit", LocalDate.of(1990, 05, 17));
 
 //for (Student student : stu) {
 
		while(yes) {
			System.out.println("Enter Student Name : ");
			studentName = sc.nextLine();
			System.out.println("Enter Student DOB (dd/mm/yyyy) : ");
			studentDOB = sc.nextLine();
			LocalDate localDate = LocalDate.parse(studentDOB, datetimeformater);
			Student student = new Student(studentName, localDate);
  
			registerStudent(student);
			if (admissionId == 0) {
				System.out.println("Not registered ");
			} else {
				appearForExam(registerForExam(student));
			}
			System.out.println("Do you want to enter another student details (Y/N)");
			option = sc.nextLine();
			if (option.equals("N")) {
				yes = false;
			}
		}
		
		int arrLen = Registrar.getRegistrar().reg.size();
		System.out.println("Array length : " + arrLen);
		if (arrLen == 0) {
			System.out.println("Nothing to Display");
		} else {
		
			System.out.println("Display without sort");	
			Registrar.display(Registrar.getRegistrar().reg);
 
			System.out.println("Display after sorting on Name");
			Collections.sort(Registrar.getRegistrar().reg, new Student());
			Registrar.display(Registrar.getRegistrar().reg);
		}
 
 
	}

	public static void registerStudent(Student student){
		Registrar registrar=Registrar.getRegistrar();
		if (registrar.reg.size() < student.getMaxLim()) {
			admissionId = registrar.registerStudent(student);
			//System.out.println("Admission ID : " + admissionId);
		} else {
			System.out.println("Max limit reached , no more registration");
			admissionId = 0;
		}
	}

	public static Exam registerForExam(Student student) {
  //System.out.println("inside Student -> registerForExam");
		ExamRegistrar  examRegistrar=ExamRegistrar.getExamRegistrar();
		Exam exam=examRegistrar.registeringStudentForExamination(student); 
		return (exam);
	}

	public static void appearForExam(Exam exam) {
  //System.out.println("inside Student -> appearForExam ");
		Paper paper=exam.getPaper();
		result1 = paper.submit();
		if (result1 = true) {
			System.out.println("Pass : You got enrolled");
		}else {
			System.out.println("Fail : Try again"); 
		}
     
 
	}
}
