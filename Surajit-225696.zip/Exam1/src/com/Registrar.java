package com;

import java.util.ArrayList;

public class Registrar {
static int i;
static int admissionId = 0;
static ArrayList<Student> reg = new ArrayList<>();
Registrar() { 
}

static Registrar getRegistrar() {
 Registrar registrar=new Registrar();
 //System.out.println("inside Registrar -> getRegistrar");
 return registrar;
 
}

int registerStudent(Student student)  {
 //System.out.println("inside Registrar -> registerStudent");
 //if (reg.size() < student.getMaxLim()) {
  Validator validator=Validator.getValidator();
  try {
   boolean validStu = validator.validateStudentDetails(student);
   admissionId = i+1;
  
   reg.add(student);
   System.out.println(student.getName() + " added in list");
  
   return admissionId;
  } catch (AgeException e) {
   // TODO Auto-generated catch block
   e.printStackTrace();
   return 0;
  }
 //} else {
 // System.out.println("limit reached, no more registration");
 // return 0;
 //}
}

public static void display (ArrayList<Student>student) {
 System.out.println("Student Name\tDate og Birth\tAge");
 System.out.println("----------------------------------------");
 for (Student student2 : student) {
  System.out.print(student2.getName()+"\t"+"\t");
  System.out.print(student2.getDateofBirth()+ "\t");
  System.out.println(student2.getAge()+ "\t");
 } 
  
}
}
