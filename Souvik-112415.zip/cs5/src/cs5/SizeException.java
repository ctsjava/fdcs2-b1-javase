package cs5;

public class SizeException extends Exception{
	
	String msg;
	SizeException(String msg)
	{
		this.msg=msg;
	}
	@Override
	public String toString() {
		return ("Exception !!!"+msg);
	}
}
