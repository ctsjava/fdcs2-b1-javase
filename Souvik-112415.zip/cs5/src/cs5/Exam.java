package cs5;

public class Exam {
	
	private Paper paper ;
	
	public Exam(Paper pr)
	{
		this.paper=pr;
	}

	public Paper getPaper() {
		return paper;
	}

}
