package cs5;

import java.util.ArrayList;
import java.util.Collections;

public class Controller {
	public static void main(String[] args) {
		
		Student s1 = new Student("James", "Married", 25, 'M', "10/7/1994", "Delhi", "abc@abc.com", "xyz@xyz.com",
				9876543765L, "Java", "Mtech", "Indian");
		Student s2 = new Student("Amy", "Single", 26, 'F', "10/7/1993", "Kolkata", "abc@abc.com", "xyz@xyz.com",
				9876543766L, "Java", "Btech", "Indian");
		Student s3 = new Student("Lopa", "Single", 31, 'F', "10/7/1987", "Delhi", "abc@abc.com", "xyz@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		Student s4 = new Student("Sammy", "Single", 27, 'M', "10/7/1992", "Kolkata", "abc@abc.com", "xyz@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		Student s5 = new Student("Lisa", "Single", 35, 'F', "10/7/1991", "Orissa", "abc@abc.com", "xyz@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		Student s6 = new Student("Opara", "Single", 25, 'M', "10/7/1994", "Kolkata", "abc@abc.com", "xyz@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		Student s7 = new Student("Kasa", "Single", 27, 'M', "10/7/1992", "Orissa", "abc@abc.com", "xyz@xyz.com",
				9876443765L, "Java", "Mtech", "Indian");
		
		Registrar rs=new Registrar();
		ArrayList al=new ArrayList();
		
		rs.registerStudent(al, s1);
		rs.registerStudent(al, s2);
		rs.registerStudent(al, s3);
		rs.registerStudent(al, s4);
		rs.registerStudent(al, s5);
		rs.registerStudent(al, s6);
		rs.registerStudent(al, s7);
		rs.evaluationProcess(al);
		System.out.println("****** Displaying Students *******");
		System.out.println();
		rs.displayStudent(al);
		System.out.println();
		
		System.out.println("****** Sorting Students Based On Name*******");
		System.out.println();
		Collections.sort(al, rs.sortName());
		rs.displayStudent(al);
	}
}
