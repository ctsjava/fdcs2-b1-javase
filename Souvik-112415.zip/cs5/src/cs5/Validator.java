package cs5;

public class Validator {
	
	public boolean validateStudent(Student st)
	{
		boolean validate=false;
		
		try {
			if(st.getAge()>23 && st.getAge()<35)
			{
				validate=true;				
			}
			else
			{
				validate=false;
				throw new AgeException("Student "+st.getName()+" is not between 23 and 35 ");
			}
			
		} catch (AgeException e) {
			System.out.println(e);
		}
		finally {
			return validate;
		}
		
	}

}
