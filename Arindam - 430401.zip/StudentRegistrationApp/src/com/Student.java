package com;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;
import java.util.Comparator;

public class Student implements Serializable, Comparable<Student>, Comparator<Student>{

/**
 * 
 */
private static final long serialVersionUID = 20L;
private String Name;
private LocalDate DateofBirth;
private int age;

private final int max_seat = 2;

static Exam exam;
static String result;

public Student() {
 
}

public Student(String name, LocalDate dateofBirth) {
 Name = name;
 DateofBirth = dateofBirth;
}

public String getName() {
 return Name;
}

public void setName(String name) {
 this.Name = name;
}

public LocalDate getDateofBirth() {
 return DateofBirth;
}

public void setDateofBirth(LocalDate dateofBirth) {
 this.DateofBirth = dateofBirth;
}

public int getAge() {
 Period period = Period.between(getDateofBirth(), LocalDate.now());
        this.age = period.getYears();
        return this.age;
}

public int getMax_seat() {
 return max_seat;
}

@Override
public int compareTo(Student student) {
 return this.age - student.getAge();
}

@Override
public int compare(Student o1, Student o2) {
 return o1.getName().compareTo(o2.getName());
}


}
 
