package com;

public class Exam {

Paper paperobj;

Exam( Paper paperobj){
 this.paperobj = paperobj;
}

Paper getPaper() {
 return this.paperobj;
}

}
