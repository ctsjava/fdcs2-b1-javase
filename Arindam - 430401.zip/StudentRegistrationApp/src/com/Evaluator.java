package com;

public class Evaluator {

private Evaluator(){
 
}

static Evaluator getEvaluator() {
 Evaluator evaluator = new Evaluator();
 return evaluator;
}

String evaluate(Paper paper) {
 String result = "Passed";
 //System.out.println("Evaluator evaluated the " +paper.p +"and " +result +" passed the examinee.");
 return result;
}
}
