package com;

import java.util.ArrayList;
import java.util.Random;

public class Registrar {
static int admissionid;
static ArrayList<Student> reg_student = new ArrayList<>();

private Registrar(){

}

static Registrar getRegistrar(){
 Registrar r = new Registrar();
 return r;
}

int registerStudent(Student student){
 System.out.println("<--------------------------------------------------------------------------------->");
 System.out.println("Request received to Registrar for :  " +student.getName());
 admissionid = 0;
  Validator validator = Validator.getValidator(); 
  try {
   boolean x = validator.validateStudentDetails(student);
   if (x == true) {
    Random random = new Random();
    admissionid = random.nextInt(40000);
    reg_student.add(student);
   }
  } catch (AgeException e) {
   admissionid = 0;
   System.out.println("Age exception occoured.");
   e.printStackTrace();
  }
 
 return admissionid;  
}

public static void display(ArrayList<Student> student) {
 
        System.out.println("Student Name\tDate of Birth \tAge");
        System.out.println("<--------------------------------------------------------------------------------->");
        for(Student std:student) {
            System.out.print(std.getName() +"\t\t");
            System.out.print(std.getDateofBirth() +"\t");
            System.out.print(std.getAge() +"\t");
            System.out.println();
        }
        System.out.println("<--------------------------------------------------------------------------------->");
        System.out.println("<xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx>");
}



}
