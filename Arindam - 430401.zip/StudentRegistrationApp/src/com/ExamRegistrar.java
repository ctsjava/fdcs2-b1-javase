package com;

public class ExamRegistrar {

ExamRegistrar() {
 
}


static ExamRegistrar getExamRegistrar() {
 ExamRegistrar examreg = new ExamRegistrar();
 return examreg;
}

 Exam registeringStudentForExamination (Student student) {
 System.out.println("Exam Registrar received information about " +student.getName() +" who will be sitting for exam.");
 Paper p1 = new Paper();
 System.out.println("Examinar set programming paper.");
 Exam exam = new Exam(p1);
 return exam;

}

}
