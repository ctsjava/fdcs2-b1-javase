package com;

public class Validator {

private Validator() {
 
}

static Validator getValidator(){
 Validator v = new Validator();
 return v;
}

 boolean validateStudentDetails (Student student) throws AgeException{
  
  if ((student.getAge() >= 23) && (student.getAge() <= 35)) {
   System.out.println("Validation Successfully for " +student.getName() +" requested by Registrar");
         return true;
     } else {
      throw new AgeException("Age out of bounds :" +student.getAge());
     }
  
}

}
