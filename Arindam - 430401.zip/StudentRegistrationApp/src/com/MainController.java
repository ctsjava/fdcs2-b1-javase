package com;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Scanner;

public class MainController {
	
	static Exam exam;
	static String result;
	
	public static int registerStudent(Student student) {
		Registrar registrar = Registrar.getRegistrar();
		
		int admissionid = 0;
		if(registrar.reg_student.size() <= student.getMax_seat()) {
			admissionid = registrar.registerStudent(student);
		}else {
			System.out.println("Sorry, vaccancy is full. Cannot register student. " +student.getName());
			admissionid = 0;
		}
		
		if (admissionid != 0) {
			System.out.println("Validation successfull. Application ID: " +admissionid +" generated for " +student.getName());
			System.out.println("Student " +student.getName() +" successfully enrolled to the University...");
			System.out.println("-----------------------------------------------------------------------------------");	
		}else {
			System.out.println("Validation un-successfull. Application ID not generated for " +student.getName() +" age : " +student.getAge());
			System.out.println("Student " +student.getName() +" enrollement to the University failed!!!!...");
			System.out.println("-----------------------------------------------------------------------------------");
		}
		return admissionid;
		
	}
	
	  public static Exam registerForExam(Student student) {
		 System.out.println(student.getName() + " was registered for Examination.");
		 ExamRegistrar examreg = ExamRegistrar.getExamRegistrar();
		 Exam exam = examreg.registeringStudentForExamination(student);
		 System.out.println("Examination will be conducted on " +exam.paperobj.p +" subject for " +student.getName());
		 System.out.println("-----------------------------------------------------------------------------------");
		 return exam;
	 }
	  
	 
	  public static void appearForExam(Exam exam){

		 Paper paper = exam.getPaper();
		 System.out.println("Student appeared for the exam of " +exam.paperobj.p +" and submitted the paper.");
		 result = paper.submit();
		 if (result == "Passed") {
			 System.out.println("Final result: Student passed the " +exam.paperobj.p +" exam and admitted to the university.");
		 }else {
			 System.out.println("Final result: Student failed in  " +exam.paperobj.p +" exam and disqualified for University admission.");
		 }
		 
		 System.out.println("<--------------------------------------------------------------------------------->");
		 System.out.println("<------------------   Student Admission Complete   ------------------------------->");
		 System.out.println("<xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx>");
		}


	public static void main(String[] args) {
		
		int applicationid = 0;
		//Student s1 = new Student("Arindam", LocalDate.of(1990, 05, 06));
		//Student s2 = new Student("Surajit", LocalDate.of(1984, 05, 06));
		//Student s3 = new Student("Sucheta", LocalDate.of(1970, 05, 06));
		//Student s4 = new Student("Rudra", LocalDate.of(1989, 05, 06));
		//Student s5 = new Student("Ayan", LocalDate.of(1988, 05, 06));
		
		//ArrayList<Student> stud_que = new ArrayList<>();
		//stud_que.add(s1);
		//stud_que.add(s2);
		//stud_que.add(s3);
		//stud_que.add(s4);
		//stud_que.add(s5);
		
		//for (Student student : stud_que) {
		//	applicationid = registerStudent(student);
		//	if (applicationid == 0) {
		//		System.out.println("Student registration failed....");
		//		System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
		//	}else {
		//		appearForExam(registerForExam(student));
		//	}
		//}
		
		Scanner sc = new Scanner(System.in);
		DateTimeFormatter datetimeformater = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String studentName = null;
		String studentDOB = null;
		String option = null;
		boolean yes = true;
		
		while(yes) {
			System.out.println("<--------------------------------------------------------------------------------->");
			System.out.println("<----------------------  Student Details Entry System   -------------------------->");
			System.out.println("<--------------------------------------------------------------------------------->");
			System.out.println("Please enter the name of student             : ");
			studentName = sc.nextLine();
			System.out.println("Please enter the DOB of student (dd/mm/yyyy) : ");
			studentDOB = sc.nextLine();
			LocalDate localDate = LocalDate.parse(studentDOB, datetimeformater);
			
			Student student = new Student(studentName, localDate);
			applicationid = registerStudent(student);
			if (applicationid == 0) {
				System.out.println("Student registration failed....");
				System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
			}else {
				appearForExam(registerForExam(student));
			}
			
			System.out.println("Do you want to enter another student details (Y/N)");
			option = sc.nextLine();
			if (option.equals("N")) {
				yes = false;
				System.out.println("<------------------------   Data Entry Complete   ------------------------------->");
				System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
			}
		}
		
		sc.close();
		
		if (Registrar.getRegistrar().reg_student.size() > 0) {
			System.out.println("<--------------------------------------------------------------------------------->");
			System.out.println("<----------------------------   Original Data    --------------------------------->");
			System.out.println("<--------------------------------------------------------------------------------->");
			Registrar.display(Registrar.getRegistrar().reg_student);
			Collections.sort(Registrar.getRegistrar().reg_student, new Student());
			System.out.println("<--------------------------------------------------------------------------------->");
			System.out.println("<------------------------   Original Sorted Data on Name  ------------------------>");
			System.out.println("<--------------------------------------------------------------------------------->");
			Registrar.display(Registrar.getRegistrar().reg_student);
			Collections.sort(Registrar.getRegistrar().reg_student);
			System.out.println("<--------------------------------------------------------------------------------->");
			System.out.println("<------------------------   Original Sorted Data on Age  ------------------------->");
			System.out.println("<--------------------------------------------------------------------------------->");
			Registrar.display(Registrar.getRegistrar().reg_student);
		}else {
			System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
			System.out.println("No student register / passed the exam for this University till now...");
			System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
		}
		
		

	}

}
