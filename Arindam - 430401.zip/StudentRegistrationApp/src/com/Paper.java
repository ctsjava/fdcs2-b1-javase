package com;

public class Paper {

	 String p = "Programming";

	String submit() {
	 Evaluator eval = Evaluator.getEvaluator();
	 String result = eval.evaluate(this);
	 if (result == "Passed") {
	  return "Passed";
	 }else {
	  return "Failed";
	 }
	}
	}
