package com;

public class AgeException extends Exception {

private static final long serialVersionUID = 20L;

  public AgeException(String message){
   super(message);
  }

}
